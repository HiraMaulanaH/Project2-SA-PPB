package com.example.dapurmamamenu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AdapterMenu menuAdapter;
    private List<ItemMenu> listMenu;
    private Button btnTotal;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnTotal = findViewById(R.id.btnTotalBayar);
        recyclerView = findViewById(R.id.rycView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        listMenu = new ArrayList<>();
        int gadoGado = getResources().getIdentifier("gado_gado","drawable",getPackageName());
        int nasiLontong = getResources().getIdentifier("nasi_lontong_tahu","drawable",getPackageName());
        int nasiPecel = getResources().getIdentifier("nasi_pecel","drawable",getPackageName());
        int nasiSoto = getResources().getIdentifier("nasi_soto","drawable",getPackageName());
        int esTeh = getResources().getIdentifier("es_teh", "drawable", getPackageName());
        int esJeruk = getResources().getIdentifier("es_jeruk", "drawable", getPackageName());

        listMenu.add(new ItemMenu("Nasi Lontong Tahu", "Nasi dengan lontong dan tahu", 35000, nasiLontong));
        listMenu.add(new ItemMenu("Nasi Pecel", "Nasi dipecel bukan dibakar", 30000, nasiPecel));
        listMenu.add(new ItemMenu("Nasi Soto", "Nasi didampingi soto", 25000, nasiSoto));
        listMenu.add(new ItemMenu("Gado-Gado", "Gado gado lezat maknyus", 25000, gadoGado));
        listMenu.add(new ItemMenu("Es Teh", "Es Teh bukan teh hangat", 15000, esTeh));
        listMenu.add(new ItemMenu("Es Jeruk", "Es jeruk dengan rasa jeruk", 20000, esJeruk));

        menuAdapter = new AdapterMenu(listMenu);
        recyclerView.setAdapter(menuAdapter);

        dbHelper = new DatabaseHelper(this);
//        SQLiteDatabase db = dbHelper.getWritableDatabase();
//        db.delete(DatabaseHelper.TABLE_NAME_ORDER, null, null);
//        db.close();

        int totalHargaDariDatabase = dbHelper.getTotalHargaFromDatabase();

        // Cek apakah total harga lebih dari 0, jika ya, tampilkan tombol dan set teksnya
        if (totalHargaDariDatabase > 0) {
            btnTotal.setVisibility(View.VISIBLE);
            btnTotal.setText("Bayar Pesanan (Total: Rp " + totalHargaDariDatabase + ")");
        } else {
            btnTotal.setVisibility(View.GONE);
        }

    }

    public void toRiwayat(View view) {
//        Intent intent = new Intent(this, RiwayatActivity.class);
//        startActivity(intent);
    }

    public void toDaftarPesanan(View view) {
//        Intent intent = new Intent(this, DaftarPesananActivity.class);
//        startActivity(intent);
    }
}