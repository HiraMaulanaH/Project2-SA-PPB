package com.example.dapurmamamenu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class OrderActivity extends AppCompatActivity {

    private int jumlah = 1;
    private int hargaItem,gambarItem;
    private Button btnOrderrr;
    private TextView txtQuantity,txtTotalHarga,namaMenu,deskripsiMenu,hargaMenu;
    private ImageView gambarMenu;
    private String namaItem,deskripsiItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        txtQuantity = findViewById(R.id.txtQuantity);
        txtTotalHarga = findViewById(R.id.idTotal);

        Intent intent = getIntent();
        namaItem = intent.getStringExtra("namaItem");
        deskripsiItem = intent.getStringExtra("deskripsiItem");
        hargaItem = intent.getIntExtra("hargaItem", 0);
        gambarItem = intent.getIntExtra("gambarItem", R.drawable.es_teh);

        btnOrderrr = findViewById(R.id.btnPesanMenu);
        gambarMenu = findViewById(R.id.idGambar);
        namaMenu = findViewById(R.id.idNama);
        deskripsiMenu = findViewById(R.id.idDeskripsi);
        hargaMenu = findViewById(R.id.idHarga);

        gambarMenu.setImageResource(gambarItem);
        namaMenu.setText(namaItem);
        deskripsiMenu.setText(deskripsiItem);
        hargaMenu.setText("Harga: Rp " + hargaItem);

        updateQuantityAndTotal();

        btnOrderrr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Panggil fungsi untuk menyimpan pesanan ke dalam tabel
                DatabaseHelper dbHelper = new DatabaseHelper(OrderActivity.this);
                SQLiteDatabase db = dbHelper.getWritableDatabase();

                ContentValues values = new ContentValues();
                values.put(DatabaseHelper.COLUMN_NAME_ORDER, namaItem);
                values.put(DatabaseHelper.COLUMN_PRICE_ORDER, hargaItem);
                values.put(DatabaseHelper.COLUMN_QUANTITY_ORDER, jumlah);
                values.put(DatabaseHelper.COLUMN_TOTAL_PRICE_ORDER, jumlah * hargaItem);
                values.put(DatabaseHelper.COLUMN_ORDER_KE_ORDER, 1); // Ubah ke order ke yang sesuai
                long newRowId = db.insert(DatabaseHelper.TABLE_NAME_ORDER, null, values);

                db.close();

                Intent intent = new Intent(OrderActivity.this, SuksesOrder.class);
                intent.putExtra("namaPesan", namaItem);
                intent.putExtra("hargaPesan", hargaItem);
                intent.putExtra("jumlahPesan", jumlah);
                startActivity(intent);
            }
        });
    }

    public void tambahJumlah(View view){
        jumlah++;
        updateQuantityAndTotal();
    }

    public void kurangJumlah(View view){
        if (jumlah > 1) {
            jumlah--;
            updateQuantityAndTotal();
        }
    }

    private void updateQuantityAndTotal() {

        txtQuantity.setText(String.valueOf(jumlah));
        int totalHarga = jumlah * hargaItem;
        txtTotalHarga.setText("Total Harga: Rp " + totalHarga);
    }
}