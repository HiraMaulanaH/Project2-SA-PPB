package com.example.dapurmamamenu;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AdapterMenu extends RecyclerView.Adapter<AdapterMenu.ViewHolder> {

    private List<ItemMenu> menuItems;
    private int selectedPosition = RecyclerView.NO_POSITION;

    public AdapterMenu(List<ItemMenu> menuItems) {
        this.menuItems = menuItems;
    }

    @NonNull
    @Override
    public AdapterMenu.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_menu, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterMenu.ViewHolder holder, int position) {
        ItemMenu menuItem = menuItems.get(position);

        holder.namaMenu.setText(menuItem.getMenuNama());
        holder.deskripsiMenu.setText(menuItem.getMenuDeskripsi());
        holder.hargaMenu.setText("Rp " + menuItem.getMenuHarga());
        holder.gambarMenu.setImageResource(menuItem.getMenuGambar());

        Button btnOrderMenu = holder.itemView.findViewById(R.id.btnOrderMenu);

        btnOrderMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = v.getContext();
                Intent intent = new Intent(context, OrderActivity.class);

                intent.putExtra("namaItem", menuItem.getMenuNama());
                intent.putExtra("deskripsiItem", menuItem.getMenuDeskripsi());
                intent.putExtra("hargaItem", menuItem.getMenuHarga());
                intent.putExtra("gambarItem", menuItem.getMenuGambar());

                context.startActivity(intent);
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int previousSelectedPosition = getSelectedPosition();
                int currentPosition = holder.getAdapterPosition();

                if (previousSelectedPosition != currentPosition) {
                    selectedPosition = currentPosition;
                    notifyItemChanged(previousSelectedPosition);
                    notifyItemChanged(selectedPosition);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return menuItems.size();
    }

    public int getSelectedPosition() {
        int selectedPosition = 0;
        return selectedPosition;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView namaMenu;
        TextView deskripsiMenu;
        TextView hargaMenu;
        Button btnOrder;
        ImageView gambarMenu;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            namaMenu = itemView.findViewById(R.id.idNamaMenu);
            deskripsiMenu = itemView.findViewById(R.id.idDeskripsiMenu);
            hargaMenu = itemView.findViewById(R.id.idHargaMenu);
            btnOrder = itemView.findViewById(R.id.btnOrderMenu);
            gambarMenu = itemView.findViewById(R.id.menuItemImage);
        }
    }
}
